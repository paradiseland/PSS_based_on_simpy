# coding=utf-8
# /usr/bin/Python3.6

"""
Author: Xingwei Chen
Email:cxw19@mails.tsinghua.edu.cn
date:2021/3/11 09:57
"""


def turn_inbound_order_to_place(order):
    pass
