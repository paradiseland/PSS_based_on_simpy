# coding=utf-8
# /usr/bin/Python3.6

"""
Author: Xingwei Chen
Email:cxw19@mails.tsinghua.edu.cn
date:2021/3/9 08:40
"""
import logging
from typing import Optional, Tuple, Union, Any, List

import simpy
from simpy import Resource

from Warehouse.CONSTANT import time_load_or_unload, PSBDemo, Bin_weight, factor_of_rotating_mass, gravity_coefficient, \
    friction_coefficient, eta
from Warehouse.Stack import LENGTH, HEIGHT_OF_ONE_TIER, Stack
from Warehouse.Warehouse import HEIGHT_AVAILABLE, STACKS_OF_ONE_COL, Warehouse, NUM_OF_TIERS

HORIZONTAL_VELOCITY = 2
VERTICAL_VELOCITY = 0.3
HORIZONTAL_ACCELERATION = 2
VERTICAL_ACCELERATION = 1
PSB_WEIGHT = 72
WEIGHT_CAPACITY = 30
HORIZONTAL_DISTANCE_SIGN = HORIZONTAL_VELOCITY ** 2 / HORIZONTAL_ACCELERATION
VERTICAL_DISTANCE_SIGN = VERTICAL_VELOCITY ** 2 / VERTICAL_ACCELERATION
# F_c = G/g•a•f_r + G•c_r
# P_c = F_c • max_h_velocity / (1000 * eta)
power_of_horizontal_acceleration_unloaded = (PSBDemo.weight * PSBDemo.acc_unloaded * factor_of_rotating_mass + PSBDemo.weight * gravity_coefficient * friction_coefficient) * PSBDemo.max_velocity / (1000 * eta)  # 0.77904
power_of_horizontal_acceleration_loaded = ((PSBDemo.weight + Bin_weight) * PSBDemo.acc_unloaded * factor_of_rotating_mass + PSBDemo.weight * gravity_coefficient * friction_coefficient) * PSBDemo.max_velocity / (1000 * eta)  # 0.98604
power_of_horizontal_deceleration_unloaded = (PSBDemo.weight * PSBDemo.acc_unloaded * factor_of_rotating_mass - PSBDemo.weight * gravity_coefficient * friction_coefficient) * PSBDemo.max_velocity / (1000 * eta)  # 0.21456
power_of_horizontal_deceleration_loaded = ((PSBDemo.weight + Bin_weight) * PSBDemo.acc_unloaded * factor_of_rotating_mass - PSBDemo.weight * gravity_coefficient * friction_coefficient) * PSBDemo.max_velocity / (1000 * eta)  # 0.421
power_of_horizontal_constant_unloaded = (PSBDemo.weight * gravity_coefficient * friction_coefficient * PSBDemo.max_velocity) / (1000 * eta)  # 0.28224
power_of_horizontal_constant_loaded = ((PSBDemo.weight + Bin_weight) * gravity_coefficient * friction_coefficient * PSBDemo.max_velocity) / (1000 * eta)


# noinspection PyTypeChecker
class PSB:
    """
    
    """

    def __init__(self, name, env, init_line=None, capacity=1):
        self.reshuffle_task = []
        self.name: int = name
        self.env: simpy.Environment = env
        self.resource: simpy.Resource = Resource(env, capacity)
        self.line: Optional[int] = init_line
        self.current_place: Optional[Tuple[int, int]] = (self.line, -1)  # 记初始为工作台位置
        self.idle: bool = True
        self.energy_consumption_for_current_order = 0
        # type_ of this operation : "S"/"R"
        self.total_work_time: float = 0.0
        self.work_time_for_current_order: List[str, float] = ['R', 0.0]

    def go_to_horizontally(self, target: Tuple[int, int], loaded=False) -> Union[float, Any]:
        """
        compute the time consumption from current place to target place.
        ---------------
        :param target:current place -> target place: (x, y) coordinates of the stack place. x in width and y in length.
        :param loaded: whether carrying load or not
        """
        accelerate_time, stable_move_time, time_current_place2target = self.get_horizontal_transport_time(
            abs(target[1] - self.current_place[1]) * LENGTH, loaded)
        # self.update_dwell_point(target)
        return time_current_place2target

    def get_horizontal_transport_time(self, dis: int, loaded=True):
        """
        Return the acc time, stable time and total time to finish this distance.
        :param dis:
        :param loaded:
        :param: dis: the distance of this step.
        """
        if dis <= HORIZONTAL_DISTANCE_SIGN:
            t_1 = pow((dis / HORIZONTAL_ACCELERATION), 1 / 2)
            work = PSB.get_horizontal_work(t_1, loaded=loaded)
            # energy recording, Created by Xingwei Chen 2021/4/6 17:29
            self.update_energy_consumption_for_current_order(work)
            return t_1, 0, 2 * t_1
        else:
            t_1 = HORIZONTAL_VELOCITY / HORIZONTAL_ACCELERATION
            t_2 = (dis - HORIZONTAL_DISTANCE_SIGN) / HORIZONTAL_VELOCITY
            work = PSB.get_horizontal_work(t_1, stable_time=t_2, loaded=loaded)
            # energy recording, Created by Xingwei Chen 2021/4/6 17:29
            self.update_energy_consumption_for_current_order(work)
            return t_1, t_2, 2 * t_1 + t_2

    def get_vertical_transport_time(self, tier: int, drop_off=True):
        """
        Modified by Xingwei Chen 2021/4/6 16:31
        Based on time study in PSS system, we get the law of the catch and drop off bins.
        --------
        example: catch-up: {'Tier-0': 21, 'Tier-1': 20, 'Tier-2': 19, 'Tier-3': 18, 'Tier-4': 17, 'Tier-5': 16, 'Tier-6': 15}s
                 drop-off: {'Tier-0': 24, 'Tier-1': 23, 'Tier-2': 22, 'Tier-3': 21, 'Tier-4': 20, 'Tier-5': 19, 'Tier-6': 18}
        :param tier: target tier of this stack
        :param drop_off: whether this step is dropping of current bin
        """
        #  Modified by Xingwei Chen 2021/4/6 16:06
        #  Modified by Xingwei Chen 2021/4/11 12:36
        work = PSB.get_vertical_work(tier)
        self.update_energy_consumption_for_current_order(work)
        if drop_off:
            return PSBDemo.setup_of_dropoff + (HEIGHT_AVAILABLE - tier) * PSBDemo.vertical_move_coefficient
        else:
            return PSBDemo.setup_of_catchup + (HEIGHT_AVAILABLE - tier) * PSBDemo.vertical_move_coefficient
        # if tier <= VERTICAL_DISTANCE_SIGN:
        #     t_1 = (float(tier / VERTICAL_ACCELERATION)) ** .5
        #     return t_1, 0, 2 * t_1
        # else:
        #     t_1 = VERTICAL_VELOCITY / VERTICAL_ACCELERATION
        #     t_2 = (tier - VERTICAL_DISTANCE_SIGN) / VERTICAL_VELOCITY
        #     return t_1, t_2, 2 * t_1 + t_2

    def update_dwell_point(self, target):
        self.current_place = target

    def occupied(self):
        self.idle = False

    def released(self):
        self.energy_consumption_for_current_order = 0
        self.work_time_for_current_order[1] = 0
        self.idle = True

    def transport_bin_to_destination(self, previous_y, new_y, previous_stack_tier, new_stack_tier):
        """
        transport the blocking bins to peek of adjacent stack.
        the current place of PSB doesn't change
        """
        down_up_to_peek = self.get_vertical_transport_time(previous_stack_tier, drop_off=False)
        horizon_to_back_adjacent = self.get_horizontal_transport_time((abs(previous_y - new_y)) * LENGTH)[-1] * 2
        drop_off_up = self.get_vertical_transport_time(new_stack_tier, drop_off=True)
        total_time = down_up_to_peek + horizon_to_back_adjacent + drop_off_up + time_load_or_unload * 2
        #  Modified by Xingwei Chen 2021/4/6 15:41
        return total_time

    def get_time_retrieve_bin_without_shuffle(self, stack_tier, target_stack_order):
        # (NUM_OF_TIERS - tier - 1) * HEIGHT_OF_ONE_TIER, [-1] * 2
        down_and_up_to_peek = self.get_vertical_transport_time(stack_tier, drop_off=False)
        stack2workstation_horizontally = self.get_horizontal_transport_time(target_stack_order * LENGTH)[-1]
        # NUM_OF_TIERS * HEIGHT_OF_ONE_TIER, [-1] * 2
        drop_off_up = self.get_vertical_transport_time(stack_tier, drop_off=True)
        total_time = down_and_up_to_peek + stack2workstation_horizontally + drop_off_up + time_load_or_unload * 2  # t_lu: time of loading or unloading
        return total_time

    def reshuffle_and_get_bin(self, warehouse: Warehouse, xy: tuple, stack_tier, method: str):
        if method == 'without':
            return self.get_bin_without_return(warehouse, xy, stack_tier)
        elif method == 'immediate':
            return self.get_bin_with_immediate_return(warehouse, xy, stack_tier)
        elif method == 'delayed':
            return self.get_bin_with_delayed_return()
        else:
            raise TypeError

    def get_bin_with_immediate_return(self, warehouse, xy, stack_tier):
        """
        immediate return
        reshuffle -> target bin go to temporarily place -> return blocking bins -> go to workstation.
        """
        target_bin_new_stack_y, time_reshuffle = self.reshuffle_blocking_bin(warehouse, xy, stack_tier)
        # logging.debug(f"current line = {self.current_line}, target y = {target_bin_new_stack_y}, xy = {xy}")
        time_target_bin_temporarily = self.transport_bin_to_destination(
                stack_tier,
                warehouse.stock_record[self.line][target_bin_new_stack_y].size, xy[1], target_bin_new_stack_y)
        warehouse.stock_record[xy[0]][xy[1]].pop()
        warehouse.stock_record[xy[0]][target_bin_new_stack_y].push(1)
        time_return_blocking_bins = self.return_blocking_bins(warehouse, xy[1])
        time_to_temporarily = self.get_horizontal_transport_time(abs(target_bin_new_stack_y - xy[1]) * LENGTH)[
                                  -1] + time_load_or_unload * 2
        time_to_workstation = self.get_time_retrieve_bin_without_shuffle(
                warehouse.stock_record[self.line][target_bin_new_stack_y].size, target_bin_new_stack_y)
        warehouse.stock_record[xy[0]][target_bin_new_stack_y].pop()

        total_time = time_reshuffle + time_target_bin_temporarily + time_return_blocking_bins \
                     + time_to_temporarily + time_to_workstation

        return total_time

    def get_bin_without_return(self, warehouse, xy, stack_tier):
        target_bin_new_stack_y, time_reshuffle = self.reshuffle_blocking_bin(warehouse, xy, stack_tier)
        warehouse.stock_record[xy[0]][xy[1]].pop()
        time_to_workstation = self.get_time_retrieve_bin_without_shuffle(
                warehouse.stock_record[self.line][target_bin_new_stack_y].size, target_bin_new_stack_y)
        total_time = time_reshuffle + time_to_workstation
        return total_time

    def get_bin_with_delayed_return(self):
        # TODO:
        pass

    def reshuffle_blocking_bin(self, warehouse: Warehouse, xy: tuple, stack_tier: int):
        """
        by reshuffle the bin of certain stack, get the target bin blocking by other bins.
        """
        this_stack: Stack = warehouse.stock_record[xy[0]][xy[1]]
        cur_y = xy[1]
        logging.debug("current stack size :{}".format(this_stack.size))
        logging.debug("target tier : {}".format(stack_tier))
        adjacent_stacks = [n for m in [(cur_y + i, cur_y - i) for i in range(1, STACKS_OF_ONE_COL)] for n in m if
                           0 <= n <= STACKS_OF_ONE_COL - 1]
        adjacent_place_chosen = 0  # start place of blocking bins in sequence
        time_of_reshuffle_blocking_bins = 0
        while this_stack.size > stack_tier + 1:
            try:
                next_stack = warehouse.stock_record[xy[0]][adjacent_stacks[adjacent_place_chosen]]
            except IndexError:
                logging.error("this stack:{}, adjacent:{}, adjacents:{}".format(this_stack.stack, adjacent_place_chosen, adjacent_stacks))

            current_bin = this_stack.size
            next_bin = next_stack.size + 1
            if next_stack.size < HEIGHT_AVAILABLE:
                if adjacent_place_chosen >= len(adjacent_stacks):
                    print("bug")
                # self.register_reshuffle(adjacent_stacks[adjacent_place_chosen])
                try:
                    this_stack.pop()
                except IndexError:
                    print("Stack is empty, cannot be popped!")
                next_stack.push(1)
                time_of_reshuffle_blocking_bins += self.transport_bin_to_destination(
                        cur_y, adjacent_stacks[adjacent_place_chosen], current_bin, next_bin)
            adjacent_place_chosen += 1

        return adjacent_stacks[adjacent_place_chosen], time_of_reshuffle_blocking_bins

    def store(self, target: tuple, warehouse: Warehouse):
        # down -> up -> storage place -> down -> up
        line, target_y = target
        down_up_to_peek = self.get_vertical_transport_time(HEIGHT_AVAILABLE, drop_off=False)
        time_wk2storage = self.go_to_horizontally((line, target_y - 1), True)
        st = warehouse.stock_record[target[0]][target[1]]
        drop_off_up = self.get_vertical_transport_time(st.size, drop_off=True)
        total_time = down_up_to_peek + time_wk2storage + drop_off_up + time_load_or_unload * 2
        return total_time

    def register_reshuffle(self, y):
        """
        reshuffle task is recorded in the form of int of y coordinate + [last y].
        :param y:
        :return:
        """
        self.reshuffle_task.append([self.line, y])

    def return_blocking_bins(self, warehouse: Warehouse, last_y: int):
        """
        when the reshuffle task is not null, we came back and complete the reshuffling
        """
        # pre_y = self.reshuffle_task.pop()
        previous_stack = warehouse.stock_record[self.line][last_y]
        time_return_blocking = 0

        while len(self.reshuffle_task) > 0:
            line, next_y = self.reshuffle_task.pop()
            warehouse.stock_record[self.line][next_y].pop()
            previous_stack.push(1)
            new_stack_tier = previous_stack.size
            time_return_blocking += self.transport_bin_to_destination(
                    next_y, last_y, warehouse.stock_record[self.line][next_y].size + 1, new_stack_tier)
        return time_return_blocking

    def get_work_horizontally(self, time_acc, time_constant=0, total_weight=PSBDemo.weight):
        pass

    @staticmethod
    def get_horizontal_work(acc_time, stable_time=0, loaded=False) -> Union[int, float]:
        """
        W = P_acc * t_1 + P_dec * t_1 + P_cons * t_stable

        :param acc_time: time of PSB accelerating
        :param stable_time: time of PSB with constant speed
        :param loaded: if this PSB is carrying a bin.
        :return: work of horizontal moving.
        """
        if loaded:
            return power_of_horizontal_acceleration_loaded * acc_time + \
                   power_of_horizontal_deceleration_loaded * acc_time + \
                   power_of_horizontal_constant_loaded * stable_time
        else:
            return power_of_horizontal_acceleration_unloaded * acc_time + \
                   power_of_horizontal_deceleration_unloaded * acc_time + \
                   power_of_horizontal_constant_unloaded * stable_time

    @staticmethod
    def get_vertical_work(tier) -> Union[int, float]:
        """
        W = mgh.
        while unloaded, we compute the work by W = 1/2 (m_belt_down)gh, which using calculus.
        :param tier:
        # :param drop_off: if the move is dropping off a bin
        :return: work of this work, including down and up
        """
        # if drop_off:
        #     return (
        #                        HEIGHT_AVAILABLE - tier) / HEIGHT_AVAILABLE * PSBDemo.weight_of_belt * 1 / 2 * gravity_coefficient * (
        #                        HEIGHT_OF_ONE_TIER - tier - 1) * HEIGHT_OF_ONE_TIER
        # else:
        #     # return (HEIGHT_AVAILABLE - tier) / HEIGHT_AVAILABLE * PSBDemo.weight_of_belt * 1/2 * gravity_coefficient * (HEIGHT_OF_ONE_TIER - tier -1) * HEIGHT_OF_ONE_TIER
        #     return (
        #                        HEIGHT_AVAILABLE - tier) / HEIGHT_AVAILABLE * PSBDemo.weight_of_belt * 1 / 2 * gravity_coefficient * (
        #                        HEIGHT_OF_ONE_TIER - tier - 1) * HEIGHT_OF_ONE_TIER + \
        #            (PSBDemo.weight + Bin_weight) * gravity_coefficient * (
        #                        HEIGHT_OF_ONE_TIER - tier - 1) * HEIGHT_OF_ONE_TIER
        work = (HEIGHT_AVAILABLE - tier) / HEIGHT_AVAILABLE * PSBDemo.weight_of_belt * gravity_coefficient * (NUM_OF_TIERS - tier - 1) * HEIGHT_OF_ONE_TIER + Bin_weight * gravity_coefficient * (NUM_OF_TIERS - tier - 1) * HEIGHT_OF_ONE_TIER
        return work

    def update_energy_consumption_for_current_order(self, new_consumption):
        print("ec: "+str(new_consumption))
        self.energy_consumption_for_current_order += new_consumption

    def update_psb_time_for_current_order(self, new_work_time):
        self.work_time_for_current_order[1] += new_work_time
